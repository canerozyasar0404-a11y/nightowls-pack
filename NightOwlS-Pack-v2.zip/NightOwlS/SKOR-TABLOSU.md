# Skor tablosu (NightTab)

Sağdaki tablo `Board.java` ile çizilir, satırlar `config.yml` -> `scoreboard.satirlar` içindedir.
Her saniye yenilenir. Login dünyasında görünmez.

## Otomatik gelenler
- `<ad>`, `<rutbe>`, `<rol>`, `<cevrimici>`, `<ping>`, `<tarih>`, `<saat>`
- `<para>`, `<afkcoin>`, `<kredi>`: NightEco kuruluysa NightEcoApi'den okunur (çevrimiçi oyuncu için bellekten, veritabanına gitmez).

## Takım, claim, oy partisi: diğer eklentiden bağlama
NightTab'e derleme bağımlılığı eklemene gerek yok. Eklentin oyuncuya **metadata** yazar, tablo bunu okur.

| Satır | Metadata anahtarı |
|---|---|
| Takım | `nightboard_takim` |
| Claim hakkı | `nightboard_claim` |
| Oy partisi | `nightboard_oypartisi` |
| (isteğe bağlı) para / AFK Coin / kredi | `nightboard_para`, `nightboard_afkcoin`, `nightboard_kredi` (NightEco'yu ezer) |

```java
// değer değişince (ya da oyuncu girince) yaz:
player.setMetadata("nightboard_takim", new FixedMetadataValue(this, "Baykuşlar"));
player.setMetadata("nightboard_claim", new FixedMetadataValue(this, String.valueOf(claimHakki)));
player.setMetadata("nightboard_oypartisi", new FixedMetadataValue(this, "10/50"));

// takımdan çıkınca sil, tabloda varsayılan ("Yok") görünür:
player.removeMetadata("nightboard_takim", this);
```
Not: metadata oyuncu çıkınca silinir, bu yüzden oyuncu girince (PlayerJoinEvent) tekrar yazılmalı.
Değerler düz yazıdır (MiniMessage etiketi işlenmez).

## Satır düzeni
`lines` listesinde `""` boş satırdır. En fazla 15 satır. Sırayı, renkleri ve yazıları değiştirebilirsin.
İkonlar için resource pack hazır olunca satır başına font karakteri eklenecek.

## Logo ve ikonlar (resource pack)
`NightOwlS-Pack.zip` içinde `nightowls:icons` adlı bir font var. Karakterler:

| Karakter | Yer tutucu | Resim |
|---|---|---|
| U+E000 | (başlık, `icons: true` iken otomatik) | NightOwlS logosu |
| U+E001 | `<i_owl>` | baykuş |
| U+E002 | `<i_crown>` | taç |
| U+E003 | `<i_bag>` | para kesesi |
| U+E004 | `<i_globe>` | yeryüzü |
| U+E005 | `<i_clock>` | saat |
| U+E006 | `<i_swords>` | kılıçlar |
| U+E007 | `<i_grass>` | çim bloğu (claim) |
| U+E008 | `<i_invite>` | davetiye (oy partisi) |
| U+E010 | (tab başlığı, `icons: true` iken otomatik) | tab logosu (SURVIVAL'lı) |
| U+E00F | `<i_bos>` | ikon genişliğinde boşluk |

Açmak için `config.yml`: `resource-pack.enabled/url/sha1` doldur ve `scoreboard.icons: true` yap.
Logo başlıktan yukarı taşar. Yüksekliği/konumu değiştirmek için pack içinde `assets/nightowls/font/icons.json` -> logo `height` ve `ascent` değerleri.
Yeni ikon eklemek: PNG'yi `textures/font/` altına koy, icons.json'a yeni bir karakterle ekle, eklentide `ICONS` listesine yaz.
