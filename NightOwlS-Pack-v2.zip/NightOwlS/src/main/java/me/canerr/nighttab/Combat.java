package me.canerr.nighttab;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.projectiles.ProjectileSource;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Savas (PvP) modu: oyuncu oyuncuya vurunca ikisinde de sure baslar.
 * Sure boyunca izinli komutlar disinda komut yazilamaz, cikan oyuncu idam edilir.
 */
public class Combat implements Listener, TabExecutor {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final NightTab plugin;

    // oyuncu -> savasin biteceği zaman (ms)
    private final Map<UUID, Long> tagged = new HashMap<>();
    // /pvpbypass acik olanlar (sunucu yeniden baslayana kadar)
    private final Set<UUID> bypass = new HashSet<>();
    // savastan kacip idam edilenler: yeniden dogunca spawn'a isinlanir
    private final Set<UUID> punished = new HashSet<>();
    // idam sirasinda olum mesajini gizlemek icin
    private final Set<UUID> executing = new HashSet<>();

    private final File dataFile;

    private boolean enabled;
    private long durationMs;
    private Set<String> allowedCommands;
    private String respawnWorld;
    private double rx, ry, rz;
    private float ryaw, rpitch;

    public Combat(NightTab plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "combat-data.yml");
        loadSettings();
        loadData();
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 10L, 10L);
    }

    private void loadSettings() {
        var cfg = plugin.getConfig();
        enabled = cfg.getBoolean("combat.enabled", true);
        durationMs = Math.max(1, cfg.getInt("combat.duration-seconds", 15)) * 1000L;
        List<String> cmds = cfg.contains("combat.allowed-commands")
                ? cfg.getStringList("combat.allowed-commands")
                : List.of("msg", "tell", "w", "r", "reply");
        allowedCommands = new HashSet<>();
        for (String c : cmds) {
            allowedCommands.add(c.toLowerCase(Locale.ROOT).replace("/", ""));
        }
        respawnWorld = cfg.getString("combat.respawn.world", "spawn");
        rx = cfg.getDouble("combat.respawn.x", 210.5);
        ry = cfg.getDouble("combat.respawn.y", 9.0);
        rz = cfg.getDouble("combat.respawn.z", 208.5);
        ryaw = (float) cfg.getDouble("combat.respawn.yaw", 0.0);
        rpitch = (float) cfg.getDouble("combat.respawn.pitch", 0.0);
    }

    private String msg(String key, String def) {
        return plugin.getConfig().getString("combat.messages." + key, def);
    }

    private void loadData() {
        if (!dataFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dataFile);
        for (String s : y.getStringList("punished")) {
            try {
                punished.add(UUID.fromString(s));
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    private void saveData() {
        YamlConfiguration y = new YamlConfiguration();
        List<String> list = new ArrayList<>();
        for (UUID id : punished) list.add(id.toString());
        y.set("punished", list);
        try {
            y.save(dataFile);
        } catch (IOException ex) {
            plugin.getLogger().warning("combat-data.yml kaydedilemedi: " + ex.getMessage());
        }
    }

    // ------------------------------------------------------------------ sure

    private boolean isTagged(UUID id) {
        Long until = tagged.get(id);
        if (until == null) return false;
        if (System.currentTimeMillis() >= until) {
            return false;
        }
        return true;
    }

    private long remainingSeconds(UUID id) {
        Long until = tagged.get(id);
        if (until == null) return 0;
        long left = until - System.currentTimeMillis();
        return Math.max(1, (left + 999) / 1000);
    }

    private void tag(Player p) {
        if (bypass.contains(p.getUniqueId())) return;
        boolean already = isTagged(p.getUniqueId());
        tagged.put(p.getUniqueId(), System.currentTimeMillis() + durationMs);
        if (!already) {
            p.sendMessage(MM.deserialize(msg("entered",
                    "<red>Savaşa girdin!</red> <gray>Savaş bitene kadar komut kullanamazsın. Oyundan çıkarsan idam edilirsin.</gray>")));
        }
    }

    private void tick() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<UUID, Long>> it = tagged.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Long> en = it.next();
            Player p = Bukkit.getPlayer(en.getKey());
            if (now >= en.getValue()) {
                it.remove();
                if (p != null && p.isOnline()) {
                    p.sendMessage(MM.deserialize(msg("ended",
                            "<green>Savaş sona erdi.</green> <gray>Artık komut kullanabilirsin.</gray>")));
                    p.sendActionBar(MM.deserialize(msg("actionbar-ended", "<green>Savaş sona erdi</green>")));
                }
            } else if (p != null && p.isOnline()) {
                // Geri sayim: AFK Coin yazisinin oldugu action bar'da gosterilir
                long left = Math.max(1, (en.getValue() - now + 999) / 1000);
                p.sendActionBar(MM.deserialize(msg("actionbar", "<red>Savaş bitmesine:</red> <yellow>{sure} sn</yellow>")
                        .replace("{sure}", String.valueOf(left))));
            }
        }
    }

    // ----------------------------------------------------------------- olaylar

    private Player attackerOf(Entity damager) {
        if (damager instanceof Player p) return p;
        if (damager instanceof Projectile proj) {
            ProjectileSource src = proj.getShooter();
            if (src instanceof Player p) return p;
        }
        return null;
    }

    private boolean isNpc(Player p) {
        return p.hasMetadata("NPC");
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!enabled) return;
        if (!(e.getEntity() instanceof Player victim)) return;
        Player attacker = attackerOf(e.getDamager());
        if (attacker == null || attacker.equals(victim)) return;
        if (isNpc(victim) || isNpc(attacker)) return;
        if (e.getFinalDamage() <= 0 && e.getDamage() <= 0) return;
        tag(victim);
        tag(attacker);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        if (!enabled) return;
        Player p = e.getPlayer();
        if (!isTagged(p.getUniqueId())) return;

        String raw = e.getMessage();
        if (raw.length() < 2) return;
        String label = raw.substring(1).split(" ", 2)[0].toLowerCase(Locale.ROOT);
        String name = label;
        Command cmd = Bukkit.getCommandMap().getCommand(label);
        if (cmd != null) name = cmd.getName().toLowerCase(Locale.ROOT);

        if (allowedCommands.contains(label) || allowedCommands.contains(name)) return;
        // LuckPerms ile komut bazli izin: nightowls.combat.komut.<komut>
        if (p.hasPermission("nightowls.combat.komut." + name) || p.hasPermission("nightowls.combat.komut." + label)) return;

        e.setCancelled(true);
        String text = msg("command-blocked", "<red>Savaştayken komut kullanamazsın!</red> <gray>({sure} sn kaldı)</gray>");
        p.sendMessage(MM.deserialize(text.replace("{sure}", String.valueOf(remainingSeconds(p.getUniqueId())))));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        boolean wasTagged = isTagged(id);
        tagged.remove(id);
        if (!enabled || !wasTagged || Bukkit.isStopping() || plugin.isMaintenanceEnabled()) return;
        if (bypass.contains(id) || p.isDead()) return;

        String text = msg("combat-log", "<dark_red>{oyuncu}</dark_red> <red>savaştan kaçarak idamına karar verildi.</red>");
        Bukkit.broadcast(MM.deserialize(text.replace("{oyuncu}", p.getName())));

        punished.add(id);
        saveData();
        executing.add(id);
        try {
            p.setHealth(0.0);
        } finally {
            executing.remove(id);
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        UUID id = e.getEntity().getUniqueId();
        // olen oyuncunun suresi biter, hayatta kalanin suresi devam eder
        tagged.remove(id);
        if (executing.contains(id)) {
            e.deathMessage(null);
        }
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        if (!punished.remove(id)) return;
        saveData();
        World w = Bukkit.getWorld(respawnWorld);
        if (w == null) {
            plugin.getLogger().warning("Savas respawn dunyasi bulunamadi: " + respawnWorld);
            return;
        }
        e.setRespawnLocation(new Location(w, rx, ry, rz, ryaw, rpitch));
    }

    // ------------------------------------------------------------ /pvpbypass

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!(s instanceof Player p)) {
            s.sendMessage(MM.deserialize("<red>Bu komut sadece oyunda kullanılır.</red>"));
            return true;
        }
        if (!p.hasPermission("nightowls.combat.bypass")) {
            p.sendMessage(MM.deserialize("<red>Bu komutu kullanma yetkin yok.</red>"));
            return true;
        }
        UUID id = p.getUniqueId();
        boolean on;
        String sub = a.length == 0 ? "" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "ac", "aç", "on" -> on = true;
            case "kapat", "off" -> on = false;
            default -> on = !bypass.contains(id);
        }
        if (on) {
            bypass.add(id);
            tagged.remove(id);
            p.sendMessage(MM.deserialize("<green>Savaş modu bypass <bold>AÇIK</bold>.</green> <gray>Vurulsan da vursan da savaş süresi başlamaz.</gray>"));
        } else {
            bypass.remove(id);
            p.sendMessage(MM.deserialize("<yellow>Savaş modu bypass <bold>KAPALI</bold>.</yellow>"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (!s.hasPermission("nightowls.combat.bypass") || a.length != 1) return out;
        for (String o : List.of("ac", "kapat")) {
            if (o.startsWith(a[0].toLowerCase(Locale.ROOT))) out.add(o);
        }
        return out;
    }
}
