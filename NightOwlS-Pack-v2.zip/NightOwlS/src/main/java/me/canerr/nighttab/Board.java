package me.canerr.nighttab;

import io.papermc.paper.scoreboard.numbers.NumberFormat;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.plugin.Plugin;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.lang.reflect.Method;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Sag taraftaki skor tablosu (sidebar). Her oyuncunun kendi tablosu vardir.
 *
 * Diger eklentilerden (NightCore, takim, claim, oy partisi...) deger almak icin iki yol:
 *  1) Oyuncuya metadata yaz:  player.setMetadata("nightboard_takim", new FixedMetadataValue(plugin, "Baykuslar"));
 *     Anahtarlar: para, afkcoin, takim, claim, oypartisi
 *  2) para, afkcoin ve kredi NightEco kuruluysa otomatik okunur (NightEcoApi, bellekten).
 * Deger yoksa config'teki scoreboard.defaults kullanilir.
 */
public class Board {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    // Satirlar icin gorunmez, benzersiz isimler (renk kodlari)
    private static final String[] ENTRIES = new String[15];

    static {
        String hex = "0123456789abcde";
        for (int i = 0; i < ENTRIES.length; i++) {
            ENTRIES[i] = "§" + hex.charAt(i) + "§r";
        }
    }

    // Resource pack'teki ozel font (assets/nightowls/font/icons.json)
    private static final Key ICON_FONT = Key.key("nightowls", "icons");
    private static final String LOGO = "";
    private static final String[][] ICONS = {
            {"i_owl", ""}, {"i_crown", ""}, {"i_bag", ""},
            {"i_globe", ""}, {"i_clock", ""}, {"i_swords", ""},
            {"i_grass", ""}, {"i_invite", ""},
            {"i_bos", ""}   // i_bos: ikon kadar bosluk (hizalama icin)
    };

    private static final String DEFAULT_TITLE ="<bold><gradient:#4A00E0:#C77DFF:#4A00E0>NightOwlS</gradient></bold>";

    private static final List<String> DEFAULT_LINES = List.of(
            "<i_owl><#C77DFF>Oyuncu:</#C77DFF> <#FFD166><ad>",
            "<i_crown><#C77DFF>Rütbe:</#C77DFF> <rutbe>",
            "",
            "<i_bag><#C77DFF>Para:</#C77DFF> <#FFD166><para>",
            "<i_bag><#C77DFF>AFK Coin:</#C77DFF> <#FFD166><afkcoin>",
            "",
            "<i_grass><#7FD1FF>Claim Hakkı:</#7FD1FF> <white><claim>",
            "",
            "<i_swords><#7FD1FF>Takım:</#7FD1FF> <white><takim>",
            "",
            "<i_invite><#7FD1FF>Oy Partisi:</#7FD1FF> <white><oypartisi>",
            "<i_globe><#1FBF6B>Çevrimiçi:</#1FBF6B> <#D9FFD6><cevrimici>",
            "",
            "<gray><tarih> <saat>",
            "<gradient:#7FD1FF:#C77DFF>www.nightowls.com.tr</gradient>");

    private static final class View {
        final Scoreboard board;
        final Objective obj;
        final Team[] teams;
        final Component[] last;
        boolean shown = true;

        View(Scoreboard board, Objective obj, int lines) {
            this.board = board;
            this.obj = obj;
            this.teams = new Team[lines];
            this.last = new Component[lines];
        }
    }

    private final NightTab plugin;
    private final Map<UUID, View> views = new HashMap<>();
    private final Map<String, String> defaults = new HashMap<>();

    private boolean enabled;
    private TagResolver iconTags = TagResolver.empty();
    private Component title;
    private List<String> lines;
    private ZoneId zone;
    private DateTimeFormatter dateFmt;
    private DateTimeFormatter timeFmt;
    private boolean hideInLogin;
    private String loginWorld;

    // NightEco API'si - reflection ile, derleme bagimliligi yok
    private Object ecoApi;
    private Method ecoPara;
    private Method ecoAfk;
    private Method ecoKredi;
    private long ecoTry;

    public Board(NightTab plugin) {
        this.plugin = plugin;
        loadSettings();
        if (!enabled) return;
        long period = Math.max(5L, plugin.getConfig().getLong("scoreboard.refresh-ticks", 20L));
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, period);
    }

    private void loadSettings() {
        var cfg = plugin.getConfig();
        enabled = cfg.getBoolean("scoreboard.enabled", true);
        // icons: true ise logo ve ikonlar gorunur (oyuncularda resource pack olmali)
        boolean icons = cfg.getBoolean("scoreboard.icons", false);
        title = icons
                ? Component.text(LOGO).font(ICON_FONT).color(NamedTextColor.WHITE)
                : MM.deserialize(cfg.getString("scoreboard.title", DEFAULT_TITLE));
        List<TagResolver> tags = new ArrayList<>();
        for (String[] ic : ICONS) {
            Component c = icons
                    ? Component.text()
                    .append(Component.text(ic[1]).font(ICON_FONT).color(NamedTextColor.WHITE))
                    .append(Component.text(" "))
                    .build()
                    : Component.empty();
            tags.add(Placeholder.component(ic[0], c));
        }
        iconTags = TagResolver.resolver(tags);
        // "satirlar": eski "lines" anahtari yok sayilir, boylece eski config yeni duzeni bozmaz
        lines = cfg.contains("scoreboard.satirlar") ? cfg.getStringList("scoreboard.satirlar") : DEFAULT_LINES;
        if (lines.size() > ENTRIES.length) lines = lines.subList(0, ENTRIES.length);
        try {
            zone = ZoneId.of(cfg.getString("scoreboard.timezone", "Europe/Istanbul"));
        } catch (Exception ex) {
            zone = ZoneId.of("Europe/Istanbul");
        }
        try {
            dateFmt = DateTimeFormatter.ofPattern(cfg.getString("scoreboard.date-format", "dd/MM/yyyy"));
            timeFmt = DateTimeFormatter.ofPattern(cfg.getString("scoreboard.time-format", "HH:mm:ss"));
        } catch (IllegalArgumentException ex) {
            dateFmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            timeFmt = DateTimeFormatter.ofPattern("HH:mm:ss");
        }
        hideInLogin = cfg.getBoolean("login-hide.enabled", true);
        loginWorld = cfg.getString("login-hide.world", "login");

        defaults.put("para", "0");
        defaults.put("afkcoin", "0");
        defaults.put("takim", "Yok");
        defaults.put("claim", "0");
        defaults.put("oypartisi", "-");
        ConfigurationSection sec = cfg.getConfigurationSection("scoreboard.defaults");
        if (sec != null) {
            for (String k : sec.getKeys(false)) defaults.put(k.toLowerCase(Locale.ROOT), sec.getString(k, ""));
        }
    }

    // ------------------------------------------------------------ disaridan

    /** Tab siralamasi icin takimlarin da kopyalanmasi gereken tum oyuncu tablolari. */
    public List<Scoreboard> boards() {
        List<Scoreboard> out = new ArrayList<>();
        for (View v : views.values()) out.add(v.board);
        return out;
    }

    public void remove(UUID id) {
        views.remove(id);
    }

    /** Oyuncu girince tablosunu hemen gosterir. */
    public void show(Player p) {
        if (!enabled) return;
        ZonedDateTime now = ZonedDateTime.now(zone);
        update(p, now.format(dateFmt), now.format(timeFmt), Bukkit.getOnlinePlayers().size());
    }

    /** Eklenti kapanirken oyunculari normal tabloya dondurur. */
    public void shutdown() {
        Scoreboard main = Bukkit.getScoreboardManager().getMainScoreboard();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (views.containsKey(p.getUniqueId())) p.setScoreboard(main);
        }
        views.clear();
    }

    // ---------------------------------------------------------------- yenile

    private void tick() {
        ZonedDateTime now = ZonedDateTime.now(zone);
        String date = now.format(dateFmt);
        String time = now.format(timeFmt);
        int online = Bukkit.getOnlinePlayers().size();
        for (Player p : Bukkit.getOnlinePlayers()) {
            update(p, date, time, online);
        }
    }

    private View create(Player p) {
        Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective obj = sb.registerNewObjective("nightboard", Criteria.DUMMY, title);
        obj.numberFormat(NumberFormat.blank()); // sagdaki kirmizi numaralari gizler
        int n = lines.size();
        View v = new View(sb, obj, n);
        for (int i = 0; i < n; i++) {
            Team t = sb.registerNewTeam("nb_" + i);
            t.addEntry(ENTRIES[i]);
            v.teams[i] = t;
            obj.getScore(ENTRIES[i]).setScore(n - i);
        }
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        p.setScoreboard(sb);
        return v;
    }

    private void update(Player p, String date, String time, int online) {
        if (!enabled || !p.isOnline()) return;
        View v = views.get(p.getUniqueId());
        if (v == null) {
            v = create(p);
            views.put(p.getUniqueId(), v);
        }

        // login dunyasinda tablo gorunmesin
        boolean hide = hideInLogin && p.getWorld().getName().equals(loginWorld);
        if (hide) {
            if (v.shown) {
                v.obj.setDisplaySlot(null);
                v.shown = false;
            }
            return;
        }
        if (!v.shown) {
            v.obj.setDisplaySlot(DisplaySlot.SIDEBAR);
            v.shown = true;
        }

        Set<String> groups = plugin.groupsOf(p);
        if (groups == null) groups = Set.of();
        TagResolver res = TagResolver.resolver(
                Placeholder.unparsed("ad", p.getName()),
                Placeholder.component("rutbe", plugin.rankBadgeOf(groups)),
                Placeholder.component("rol", plugin.roleBadgeOf(groups)),
                Placeholder.unparsed("para", paraOf(p)),
                Placeholder.unparsed("afkcoin", countOf(p, "afkcoin")),
                Placeholder.unparsed("kredi", countOf(p, "kredi")),
                Placeholder.unparsed("takim", valueOf(p, "takim")),
                Placeholder.unparsed("claim", valueOf(p, "claim")),
                Placeholder.unparsed("oypartisi", valueOf(p, "oypartisi")),
                Placeholder.unparsed("cevrimici", String.valueOf(online)),
                Placeholder.unparsed("ping", String.valueOf(Math.max(0, p.getPing()))),
                Placeholder.unparsed("tarih", date),
                Placeholder.unparsed("saat", time));

        for (int i = 0; i < v.teams.length; i++) {
            String raw = lines.get(i);
            Component c = raw.isEmpty() ? Component.empty() : MM.deserialize(raw, res, iconTags);
            if (!c.equals(v.last[i])) {
                v.teams[i].prefix(c);
                v.last[i] = c;
            }
        }
    }

    // ---------------------------------------------------------------- degerler

    private String meta(Player p, String key) {
        for (MetadataValue mv : p.getMetadata("nightboard_" + key)) {
            String s = mv.asString();
            if (s != null && !s.isEmpty()) return s;
        }
        return null;
    }

    private String valueOf(Player p, String key) {
        String m = meta(p, key);
        return m != null ? m : defaults.getOrDefault(key, "");
    }

    private static final Locale TR = Locale.forLanguageTag("tr-TR");

    private String paraOf(Player p) {
        String m = meta(p, "para");
        if (m != null) return m;
        Object v = ecoCall("para", p);
        if (v instanceof Double d) {
            java.text.NumberFormat nf = java.text.NumberFormat.getNumberInstance(TR);
            boolean tam = Math.round(d * 100.0) % 100 == 0;
            nf.setMinimumFractionDigits(tam ? 0 : 2);
            nf.setMaximumFractionDigits(2);
            return nf.format(d);
        }
        return defaults.getOrDefault("para", "0");
    }

    private String countOf(Player p, String key) {
        String m = meta(p, key);
        if (m != null) return m;
        Object v = ecoCall(key, p);
        if (v instanceof Long n) return java.text.NumberFormat.getIntegerInstance(TR).format(n);
        return defaults.getOrDefault(key, "0");
    }

    /**
     * NightEco'nun API'sini (tr.nightowls.eco.NightEcoApi) reflection ile cagirir.
     * Cevrimici oyuncular icin degerler NightEco'da bellekte durur, veritabanina gitmez.
     */
    private Object ecoCall(String what, Player p) {
        if (!ecoReady()) return null;
        Method target = switch (what) {
            case "para" -> ecoPara;
            case "afkcoin" -> ecoAfk;
            default -> ecoKredi;
        };
        try {
            return target.invoke(ecoApi, p.getName());
        } catch (Throwable ex) {
            ecoApi = null; // NightEco yeniden yuklendi/kapandi, tekrar bulmayi dene
            return null;
        }
    }

    private boolean ecoReady() {
        if (ecoApi != null) return true;
        long now = System.currentTimeMillis();
        if (now - ecoTry < 10_000L) return false; // her saniye aramayalim
        ecoTry = now;
        try {
            Plugin eco = Bukkit.getPluginManager().getPlugin("NightEco");
            if (eco == null || !eco.isEnabled()) return false;
            Class<?> cls = eco.getClass().getClassLoader().loadClass("tr.nightowls.eco.NightEcoApi");
            @SuppressWarnings("unchecked")
            Object api = Bukkit.getServicesManager().load((Class<Object>) cls);
            if (api == null) return false;
            ecoPara = cls.getMethod("getPara", String.class);
            ecoAfk = cls.getMethod("getAfkCoin", String.class);
            ecoKredi = cls.getMethod("getKrediHizli", String.class);
            ecoApi = api;
            return true;
        } catch (Throwable ex) {
            return false;
        }
    }
}
