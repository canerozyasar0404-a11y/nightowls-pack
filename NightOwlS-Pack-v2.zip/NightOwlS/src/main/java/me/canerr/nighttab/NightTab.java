package me.canerr.nighttab;

import com.destroystokyo.paper.event.server.PaperServerListPingEvent;
import io.papermc.paper.chat.ChatRenderer;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.NodeType;
import net.luckperms.api.node.types.InheritanceNode;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityPortalEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class NightTab extends JavaPlugin implements Listener, TabExecutor {

    private record Badge(String label, TextColor color) {}

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final Map<String, Badge> badges = new HashMap<>();
    private List<String> topOrder;
    private List<String> rankOrder;
    private List<String> staffGroups;
    private List<String> footerGroups;
    private String defaultRank;
    private TextColor nameColor;
    private boolean colorNames;
    private boolean adFilterEnabled;
    private String adMessage;
    private List<String> adWords = new ArrayList<>();
    private boolean pingEnabled;
    private String pingFormat;
    private boolean tabLogo;
    private String headerTitle;
    private String headerStats;
    private String footerText;
    private List<String> footerInfo;
    private String headerDivider;
    private String footerDivider;
    private boolean tabSorting;
    private boolean chatEnabled;
    private String chatSeparator;
    private TextColor chatMessageColor;
    private boolean roleColoredMessages;
    private boolean loginHideEnabled;
    private String loginWorld;
    private final Map<UUID, Component> lastNames = new HashMap<>();
    private final Map<UUID, Component> lastHeaders = new HashMap<>();
    private final Map<UUID, Component> lastFooters = new HashMap<>();
    private boolean blockEnd;
    private String endMessage;
    private boolean maintenanceEnabled;
    private File maintenanceFile;
    private YamlConfiguration maintenanceData;
    private LuckPerms luckPerms;
    private Board board;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();
        luckPerms = LuckPermsProvider.get();
        loadMaintenance();
        if (getCommand("bakim") != null) {
            getCommand("bakim").setExecutor(this);
        }
        Bukkit.getPluginManager().registerEvents(this, this);
        board = new Board(this);
        Combat combat = new Combat(this);
        Bukkit.getPluginManager().registerEvents(combat, this);
        if (getCommand("pvpbypass") != null) {
            getCommand("pvpbypass").setExecutor(combat);
            getCommand("pvpbypass").setTabCompleter(combat);
        }
        long period = Math.max(20L, getConfig().getLong("refresh-ticks", 40L));
        Bukkit.getScheduler().runTaskTimer(this, this::updateAll, 40L, period);
    }

    private void loadSettings() {
        topOrder = getConfig().getStringList("top-order");
        rankOrder = getConfig().getStringList("rank-order");
        staffGroups = getConfig().getStringList("staff-groups");
        footerGroups = getConfig().getStringList("footer-groups");
        defaultRank = getConfig().getString("default-rank", "halk");
        TextColor nc = TextColor.fromHexString(getConfig().getString("name-color", "#FFFFFF"));
        nameColor = nc != null ? nc : NamedTextColor.WHITE;
        colorNames = getConfig().getBoolean("color-names", true);
        tabSorting = getConfig().getBoolean("tab-sorting", true);
        blockEnd = getConfig().getBoolean("block-end.enabled", true);
        endMessage = getConfig().getString("block-end.message", "<red>End dünyası şu an kapalı.</red>");
        loginHideEnabled = getConfig().getBoolean("login-hide.enabled", true);
        loginWorld = getConfig().getString("login-hide.world", "login");
        chatEnabled = getConfig().getBoolean("chat.enabled", true);
        chatSeparator = getConfig().getString("chat.separator", " <dark_gray>»</dark_gray> ");
        TextColor mc = TextColor.fromHexString(getConfig().getString("chat.message-color", "#E8E8E8"));
        chatMessageColor = mc != null ? mc : NamedTextColor.WHITE;
        roleColoredMessages = getConfig().getBoolean("chat.role-colored-messages", true);
        adFilterEnabled = getConfig().getBoolean("ad-filter.enabled", true);
        adMessage = getConfig().getString("ad-filter.message", "<red>Bu tarz reklamlar yasak!</red>");
        adWords = new ArrayList<>();
        List<String> words = getConfig().contains("ad-filter.blocked")
                ? getConfig().getStringList("ad-filter.blocked")
                : List.of("chatcraft", "I joined using", "Download it for free");
        for (String w : words) {
            String s = w.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]", "");
            if (!s.isEmpty()) adWords.add(s);
        }
        pingEnabled = getConfig().getBoolean("ping.enabled", true);
        pingFormat = getConfig().getString("ping.format", " <dark_gray>•</dark_gray> {ping}");
        headerTitle = getConfig().getString("header.title",
                "<bold><gradient:#5B0EA6:#C77DFF:#5B0EA6>NightOwlS Survival</gradient></bold>");
        headerStats = getConfig().getString("header.stats",
                "<gradient:#1FBF6B:#B8F5B1>Çevrimiçi:</gradient> <color:#D9FFD6>{online}</color> <dark_gray>•</dark_gray> <gradient:#1FBF6B:#B8F5B1>Yetkili:</gradient> <color:#D9FFD6>{staff}</color>");
        footerText = getConfig().getString("footer.text",
                "<gray>TPS: {tps} <dark_gray>|</dark_gray> <gray>MSPT: {mspt}");
        headerDivider = getConfig().getString("header.divider", "");
        // scoreboard.icons: true ise tab'de sadece logo gorunur (resource pack gerekir)
        tabLogo = getConfig().getBoolean("scoreboard.icons", false) && getConfig().getBoolean("tab.logo", true);
        footerDivider = getConfig().getString("footer.divider", "");
        footerInfo = getConfig().getStringList("footer.info");
        if (footerInfo.isEmpty()) {
            footerInfo = List.of(
                    "<gradient:#B388FF:#E0AAFF>IP:</gradient> <gradient:#C77DFF:#7B18FF:#C77DFF>oyna.nightowls.com.tr</gradient>",
                    "<gradient:#7FD1FF:#B388FF:#E0AAFF>www.nightowls.com.tr</gradient>");
        }
        ConfigurationSection sec = getConfig().getConfigurationSection("groups");
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            String label = sec.getString(key + ".name", key);
            TextColor color = TextColor.fromHexString(sec.getString(key + ".color", "#FFFFFF"));
            if (color == null) color = NamedTextColor.WHITE;
            badges.put(key.toLowerCase(), new Badge(label, color));
        }
    }

    @Override
    public void onDisable() {
        if (board != null) board.shutdown();
        for (Player p : Bukkit.getOnlinePlayers()) {
            for (Player o : Bukkit.getOnlinePlayers()) {
                if (!p.equals(o)) p.showPlayer(this, o);
            }
        }
        Scoreboard board = Bukkit.getScoreboardManager().getMainScoreboard();
        for (Team team : new java.util.ArrayList<>(board.getTeams())) {
            if (team.getName().startsWith("nt_")) {
                team.unregister();
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        lastNames.remove(e.getPlayer().getUniqueId());
        lastHeaders.remove(e.getPlayer().getUniqueId());
        lastFooters.remove(e.getPlayer().getUniqueId());
        for (Player o : Bukkit.getOnlinePlayers()) {
            o.showPlayer(this, e.getPlayer());
        }
        for (Scoreboard sb : allBoards()) {
            Team team = sb.getEntryTeam(e.getPlayer().getName());
            if (team != null && team.getName().startsWith("nt_")) {
                team.removeEntry(e.getPlayer().getName());
            }
        }
        board.remove(e.getPlayer().getUniqueId());
    }

    // Logo ve ikonlar icin resource pack'i oyuncuya gonderir (config: resource-pack)
    private void sendPack(Player p) {
        if (!getConfig().getBoolean("resource-pack.enabled", false)) return;
        String url = getConfig().getString("resource-pack.url", "").trim();
        if (url.isEmpty()) return;
        String sha1 = getConfig().getString("resource-pack.sha1", "").trim();
        boolean required = getConfig().getBoolean("resource-pack.required", false);
        String prompt = getConfig().getString("resource-pack.prompt",
                "<gradient:#7FD1FF:#C77DFF>NightOwlS logo ve ikonları için paketi indir</gradient>");
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!p.isOnline()) return;
            p.setResourcePack(url, sha1.isEmpty() ? null : sha1, required, MM.deserialize(prompt));
        }, 20L);
    }

    // Ana tablo + her oyuncunun kendi skor tablosu. Tab siralamasi hepsine uygulanir.
    private List<Scoreboard> allBoards() {
        List<Scoreboard> all = new ArrayList<>();
        all.add(Bukkit.getScoreboardManager().getMainScoreboard());
        all.addAll(board.boards());
        return all;
    }

    // Reklam filtresi: "I joined using ChatCraft" gibi mesajlari iptal eder.
    // Bosluk, nokta, tire vb. ile kacirmaya calismalari da yakalamak icin metin sadelestirilir.
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onAdChat(AsyncChatEvent e) {
        if (!adFilterEnabled || adWords.isEmpty()) return;
        Player p = e.getPlayer();
        if (p.hasPermission("nightowls.reklam.bypass")) return;
        String plain = PlainTextComponentSerializer.plainText().serialize(e.message());
        String squashed = plain.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]", "");
        for (String w : adWords) {
            if (squashed.contains(w)) {
                e.setCancelled(true);
                p.sendMessage(MM.deserialize(adMessage));
                getLogger().info("Reklam engellendi (" + p.getName() + "): " + plain);
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        if (!chatEnabled) return;
        Set<String> groups = groupsOf(e.getPlayer());
        if (groups == null) return;
        final Component prefix = prefixOf(groups);
        final TextColor nc = nameColorOf(groups);
        TextColor msgColor = chatMessageColor;
        String topRole = firstMatch(topOrder, groups);
        if (roleColoredMessages && topRole != null) {
            Badge topBadge = badges.get(topRole);
            if (topBadge != null) msgColor = topBadge.color();
        }
        final TextColor finalMsgColor = msgColor;
        e.renderer(ChatRenderer.viewerUnaware((source, displayName, message) ->
                Component.empty()
                        .append(prefix)
                        .append(Component.text(source.getName(), nc))
                        .append(MM.deserialize(chatSeparator))
                        .append(message.colorIfAbsent(finalMsgColor))));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        updateVisibility(e.getPlayer());
        board.show(e.getPlayer());
        updateAll(); // yeni tabloya tab siralamasi takimlarini hemen kopyalar
        sendPack(e.getPlayer());
        Bukkit.getScheduler().runTaskLater(this, this::updateAll, 10L);
    }

    // End'e giden portal ve gecitleri engeller (End'den cikisa karismaz)
    @EventHandler(ignoreCancelled = true)
    public void onPortal(PlayerPortalEvent e) {
        if (!blockEnd) return;
        TeleportCause cause = e.getCause();
        if (cause != TeleportCause.END_PORTAL && cause != TeleportCause.END_GATEWAY) return;
        Player p = e.getPlayer();
        if (p.getWorld().getEnvironment() == World.Environment.THE_END) return;
        if (p.hasPermission("nightowls.end.bypass")) return;
        e.setCancelled(true);
        p.sendMessage(MM.deserialize(endMessage));
    }

    // Tekne, minecart, at gibi araclarla (yolcu olarak) End'e gecisi engeller.
    // Arac portala girince PlayerPortalEvent degil EntityPortalEvent tetiklenir.
    @EventHandler(ignoreCancelled = true)
    public void onEntityPortal(EntityPortalEvent e) {
        if (!blockEnd) return;
        Entity ent = e.getEntity();
        if (ent.getWorld().getEnvironment() == World.Environment.THE_END) return;
        boolean toEnd = false;
        if (e.getTo() != null && e.getTo().getWorld() != null) {
            toEnd = e.getTo().getWorld().getEnvironment() == World.Environment.THE_END;
        } else {
            Material m = e.getFrom().getBlock().getType();
            toEnd = m == Material.END_PORTAL || m == Material.END_GATEWAY;
        }
        if (!toEnd) return;
        // Yolcular arasinda bypass yetkisi olan varsa gecise izin ver
        for (Entity passenger : ent.getPassengers()) {
            if (passenger instanceof Player pl && pl.hasPermission("nightowls.end.bypass")) return;
        }
        if (ent instanceof Player pl && pl.hasPermission("nightowls.end.bypass")) return;
        e.setCancelled(true);
        for (Entity passenger : new ArrayList<>(ent.getPassengers())) {
            if (passenger instanceof Player pl) {
                pl.sendMessage(MM.deserialize(endMessage));
                pl.leaveVehicle();
            }
        }
    }

    // Ender gozunu End portal cercevesine koymayi engeller (portal hic acilmaz)
    @EventHandler(ignoreCancelled = true)
    public void onEyePlace(PlayerInteractEvent e) {
        if (!blockEnd) return;
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block b = e.getClickedBlock();
        if (b == null || b.getType() != Material.END_PORTAL_FRAME) return;
        if (e.getItem() == null || e.getItem().getType() != Material.ENDER_EYE) return;
        Player p = e.getPlayer();
        if (p.hasPermission("nightowls.end.bypass")) return;
        e.setCancelled(true);
        p.sendMessage(MM.deserialize(endMessage));
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        updateVisibility(e.getPlayer());
    }

    // Login dunyasindaki oyuncular birbirini gormez
    private void updateVisibility(Player p) {
        if (!loginHideEnabled) return;
        boolean inLogin = p.getWorld().getName().equals(loginWorld);
        for (Player o : Bukkit.getOnlinePlayers()) {
            if (o.equals(p)) continue;
            boolean oLogin = o.getWorld().getName().equals(loginWorld);
            if (inLogin && oLogin) {
                p.hidePlayer(this, o);
                o.hidePlayer(this, p);
            } else {
                p.showPlayer(this, o);
                o.showPlayer(this, p);
            }
        }
    }

    private void updateAll() {
        Map<UUID, Set<String>> allGroups = new HashMap<>();
        int staffCount = 0;
        for (Player p : Bukkit.getOnlinePlayers()) {
            Set<String> groups = groupsOf(p);
            if (groups == null) continue;
            allGroups.put(p.getUniqueId(), groups);
            if (firstMatch(staffGroups, groups) != null) staffCount++;
        }

        int maxWidth = 0;
        for (Player p : Bukkit.getOnlinePlayers()) {
            Set<String> groups = allGroups.get(p.getUniqueId());
            if (groups == null) continue;
            maxWidth = Math.max(maxWidth, pixelWidth(plainPrefixOf(groups) + p.getName()));
        }

        int online = Bukkit.getOnlinePlayers().size();
        Component header = buildHeader(online, staffCount);
        Component staffFooter = buildFooter(true);
        Component publicFooter = buildFooter(false);

        for (Player p : Bukkit.getOnlinePlayers()) {
            Set<String> groups = allGroups.get(p.getUniqueId());
            if (groups == null) continue;
            updateName(p, groups, maxWidth);
            boolean seesFooter = firstMatch(footerGroups, groups) != null;
            Component footer = seesFooter ? staffFooter : publicFooter;
            UUID id = p.getUniqueId();
            if (!header.equals(lastHeaders.get(id)) || !footer.equals(lastFooters.get(id))) {
                p.sendPlayerListHeaderAndFooter(header, footer);
                lastHeaders.put(id, header);
                lastFooters.put(id, footer);
            }
        }
    }

    // Skor tablosunda "Rütbe:" satiri (tab'deki rozetin aynisi)
    Component rankBadgeOf(Set<String> groups) {
        String rank = firstMatch(rankOrder, groups);
        if (rank == null) rank = defaultRank;
        return badge(rank);
    }

    // Yetkili/medya/vip rolu (yoksa bos)
    Component roleBadgeOf(Set<String> groups) {
        String top = firstMatch(topOrder, groups);
        return top == null ? Component.empty() : badge(top);
    }

    Set<String> groupsOf(Player p) {
        if (!p.isOnline()) return null;
        User user = luckPerms.getUserManager().getUser(p.getUniqueId());
        if (user == null) return null;
        Set<String> groups = new HashSet<>();
        for (InheritanceNode node : user.getNodes(NodeType.INHERITANCE)) {
            if (!node.hasExpired()) {
                groups.add(node.getGroupName().toLowerCase());
            }
        }
        return groups;
    }

    // ---------------- Bakim modu ----------------

    public boolean isMaintenanceEnabled() {
        return maintenanceEnabled;
    }

    private void loadMaintenance() {
        getDataFolder().mkdirs();
        maintenanceFile = new File(getDataFolder(), "maintenance.yml");
        maintenanceData = YamlConfiguration.loadConfiguration(maintenanceFile);
        maintenanceEnabled = maintenanceData.getBoolean("enabled", false);
    }

    private void saveMaintenance() {
        maintenanceData.set("enabled", maintenanceEnabled);
        try {
            maintenanceData.save(maintenanceFile);
        } catch (IOException ex) {
            getLogger().warning("maintenance.yml kaydedilemedi: " + ex.getMessage());
        }
    }

    // Bakimda girebilmek icin: OP olmak ya da nightowls.bakim.bypass yetkisine sahip olmak
    private boolean isAllowed(UUID uuid, boolean online) {
        if (Bukkit.getOfflinePlayer(uuid).isOp()) return true;
        User user = online
                ? luckPerms.getUserManager().getUser(uuid)
                : luckPerms.getUserManager().loadUser(uuid).join();
        if (user == null) return false;
        return user.getCachedData().getPermissionData()
                .checkPermission("nightowls.bakim.bypass").asBoolean();
    }

    private Component kickComponent() {
        List<String> lines = getConfig().getStringList("maintenance.kick-message");
        if (lines.isEmpty()) {
            lines = List.of("<yellow>Sunucu şu an bakımda.</yellow>", "<gray>Lütfen daha sonra tekrar dene.</gray>");
        }
        return MM.deserialize(String.join("<newline>", lines));
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPreLogin(AsyncPlayerPreLoginEvent e) {
        if (!maintenanceEnabled) return;
        if (e.getLoginResult() != AsyncPlayerPreLoginEvent.Result.ALLOWED) return;
        if (!isAllowed(e.getUniqueId(), false)) {
            e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, kickComponent());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPing(PaperServerListPingEvent e) {
        if (!maintenanceEnabled || !getConfig().getBoolean("maintenance.motd.enabled", true)) return;
        String l1 = getConfig().getString("maintenance.motd.line1",
                "<bold><gradient:#4A00E0:#8E2DE2:#DA70D6>NightOwlS Survival</gradient></bold> <red>[BAKIMDA]</red>");
        String l2 = getConfig().getString("maintenance.motd.line2",
                "<yellow>Sunucu bakımda, kısa süre içinde açılacak.</yellow>");
        e.motd(MM.deserialize(l1 + "<newline>" + l2));
    }

    private void say(CommandSender s, String text) {
        s.sendMessage(MM.deserialize(text));
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!s.hasPermission("nightowls.bakim.yonet")) {
            say(s, "<red>Bu komutu kullanma yetkin yok.</red>");
            return true;
        }
        String sub = a.length == 0 ? "" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "ac", "aç", "on" -> {
                maintenanceEnabled = true;
                saveMaintenance();
                int kicked = 0;
                if (getConfig().getBoolean("maintenance.kick-online-on-enable", true)) {
                    for (Player p : new ArrayList<>(Bukkit.getOnlinePlayers())) {
                        if (!isAllowed(p.getUniqueId(), true)) {
                            p.kick(kickComponent());
                            kicked++;
                        }
                    }
                }
                say(s, "<green>Bakım modu <bold>AÇIK</bold>.</green> <gray>(" + kicked + " oyuncu atıldı)</gray>");
            }
            case "kapat", "off" -> {
                maintenanceEnabled = false;
                saveMaintenance();
                say(s, "<green>Bakım modu <bold>KAPALI</bold>.</green>");
            }
            case "durum" -> {
                say(s, "<gray>Bakım modu: " + (maintenanceEnabled ? "<red>AÇIK</red>" : "<green>KAPALI</green>") + "</gray>");
                say(s, "<gray>Girebilmek için yetki: <white>nightowls.bakim.bypass</white></gray>");
            }
            default -> say(s, "<gray>Kullanım: <white>/bakim <ac|kapat|durum></white></gray>");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (!s.hasPermission("nightowls.bakim.yonet") || a.length != 1) return out;
        for (String o : List.of("ac", "kapat", "durum")) {
            if (o.startsWith(a[0].toLowerCase(Locale.ROOT))) out.add(o);
        }
        return out;
    }

    private Component prefixOf(Set<String> groups) {
        String top = firstMatch(topOrder, groups);
        String rank = firstMatch(rankOrder, groups);
        if (rank == null) rank = defaultRank;
        Component line = Component.empty();
        if (top != null) {
            line = line.append(badge(top)).append(Component.space());
        }
        return line.append(badge(rank)).append(Component.space());
    }

    private TextColor nameColorOf(Set<String> groups) {
        String top = firstMatch(topOrder, groups);
        if (top != null && colorNames) {
            Badge topBadge = badges.get(top);
            if (topBadge != null) return topBadge.color();
        }
        return nameColor;
    }

    // Tab'de gorunen duz yazi (etiketler + bosluklar), genislik hesabi icin
    private String plainPrefixOf(Set<String> groups) {
        String top = firstMatch(topOrder, groups);
        String rank = firstMatch(rankOrder, groups);
        if (rank == null) rank = defaultRank;
        StringBuilder sb = new StringBuilder();
        if (top != null) {
            Badge b = badges.get(top);
            sb.append('[').append(b != null ? b.label() : top).append("] ");
        }
        Badge r = badges.get(rank);
        sb.append('[').append(r != null ? r.label() : rank).append("] ");
        return sb.toString();
    }

    // Minecraft varsayilan fontunda yazinin piksel genisligi
    private static int pixelWidth(String s) {
        int total = 0;
        for (char c : s.toCharArray()) {
            int w;
            switch (c) {
                case 'i', 'l', '!', ':', ';', '\'', '|', '.', ',' -> w = 1;
                case '`' -> w = 2;
                case 'I', '*', '(', ')', '{', '}', '[', ']', '"', ' ' -> w = 3;
                case 'f', 'k', 't', '<', '>' -> w = 4;
                case '@', '~' -> w = 6;
                default -> w = 5;
            }
            total += w + 1;
        }
        return total;
    }

    // Verilen piksel kadar bosluk uretir (normal bosluk 4px, kalin bosluk 5px)
    private static Component padding(int pixels) {
        if (pixels <= 0) return Component.empty();
        int bold = pixels % 4;
        int normal = (pixels - 5 * bold) / 4;
        if (normal < 0) {
            bold = 0;
            normal = pixels / 4;
        }
        Component pad = Component.text(" ".repeat(normal));
        if (bold > 0) {
            pad = pad.append(Component.text(" ".repeat(bold)).decorate(TextDecoration.BOLD));
        }
        return pad;
    }

    private void sortInTab(Player p, Set<String> groups) {
        if (!tabSorting) return;
        String top = firstMatch(topOrder, groups);
        String rank = firstMatch(rankOrder, groups);
        if (rank == null) rank = defaultRank;
        int topIndex = top == null ? 99 : Math.max(0, topOrder.indexOf(top));
        int rankIndex = rankOrder.indexOf(rank);
        if (rankIndex < 0) rankIndex = 98;
        String teamName = String.format(Locale.ROOT, "nt_%02d%02d", topIndex, rankIndex);

        for (Scoreboard sb : allBoards()) {
            Team team = sb.getTeam(teamName);
            if (team == null) team = sb.registerNewTeam(teamName);

            Team current = sb.getEntryTeam(p.getName());
            if (current != null) {
                if (current.equals(team)) continue;
                if (!current.getName().startsWith("nt_")) continue;
                current.removeEntry(p.getName());
            }
            team.addEntry(p.getName());
        }
    }

    private void updateName(Player p, Set<String> groups, int maxWidth) {
        sortInTab(p, groups);
        Component line = prefixOf(groups).append(Component.text(p.getName(), nameColorOf(groups)));
        if (pingEnabled) {
            int diff = maxWidth - pixelWidth(plainPrefixOf(groups) + p.getName());
            line = line.append(padding(diff));
            int ping = Math.max(0, p.getPing());
            String pingColor = ping <= 60 ? "green" : (ping <= 120 ? "yellow" : "red");
            String pingText = "<" + pingColor + ">" + ping + "ms</" + pingColor + ">";
            line = line.append(MM.deserialize(pingFormat.replace("{ping}", pingText)));
        }
        if (!line.equals(lastNames.get(p.getUniqueId()))) {
            p.playerListName(line);
            lastNames.put(p.getUniqueId(), line);
        }
    }

    private Component buildHeader(int online, int staff) {
        if (tabLogo) {
            // Logo 32 px yuksekliginde: 4 satir (4 x 9 px) yer ayrilir.
            // Bosluk karakterleri logonun fontunda olmadigi icin ayri (kardes) bilesen olarak eklenir.
            return Component.text()
                    .append(Component.text("")
                            .font(net.kyori.adventure.key.Key.key("nightowls", "icons"))
                            .color(net.kyori.adventure.text.format.NamedTextColor.WHITE))
                    .append(Component.text("\n \n \n "))
                    .build();
        }
        String stats = headerStats
                .replace("{online}", String.valueOf(online))
                .replace("{staff}", String.valueOf(staff));
        Component header = Component.newline()
                .append(MM.deserialize(headerTitle))
                .append(Component.newline())
                .append(Component.newline())
                .append(MM.deserialize(stats))
                .append(Component.newline());
        if (!headerDivider.isEmpty()) {
            header = header.append(MM.deserialize(headerDivider)).append(Component.newline());
        }
        return header;
    }

    private Component buildFooter(boolean withStats) {
        if (tabLogo) return Component.empty(); // logo modunda alt yazi yok
        Component footer = Component.empty();
        if (!footerDivider.isEmpty()) {
            footer = footer.append(MM.deserialize(footerDivider)).append(Component.newline());
        }
        footer = footer.append(Component.newline());
        if (withStats) {
            double tps = Math.min(20.0, Bukkit.getTPS()[0]);
            double mspt = Bukkit.getAverageTickTime();
            String tpsColor = tps >= 18.0 ? "green" : (tps >= 15.0 ? "yellow" : "red");
            String msptColor = mspt <= 40.0 ? "green" : (mspt <= 50.0 ? "yellow" : "red");
            String tpsText = "<" + tpsColor + ">" + String.format(Locale.US, "%.1f", tps) + "</" + tpsColor + ">";
            String msptText = "<" + msptColor + ">" + String.format(Locale.US, "%.1f", mspt) + "</" + msptColor + ">";
            String text = footerText.replace("{tps}", tpsText).replace("{mspt}", msptText);
            footer = footer.append(MM.deserialize(text)).append(Component.newline()).append(Component.newline());
        }
        for (String line : footerInfo) {
            footer = footer.append(MM.deserialize(line)).append(Component.newline());
        }
        return footer;
    }

    private String firstMatch(List<String> order, Set<String> groups) {
        for (String g : order) {
            if (groups.contains(g.toLowerCase())) return g.toLowerCase();
        }
        return null;
    }

    private Component badge(String group) {
        Badge b = badges.get(group);
        if (b == null) return Component.text("[" + group + "]", NamedTextColor.WHITE);
        return Component.text("[" + b.label() + "]", b.color());
    }
}
